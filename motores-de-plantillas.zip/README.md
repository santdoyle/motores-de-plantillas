# motores-de-plantillas

El proyecto está dividido en 3 branches.

Master: utiliza el motor Hundlebars. 
  $ git checkout master 

Motor-Pug: utilizar el motor PUG
  $ git checkout motor-pug

Motor-EJS utiliza el motor EJS
  $ git checkout motor-EJS

Para las vistas de los 3 branches se utilizan
  Hoja de estilos /public/styles.css
  Formulario para cargar productos /public/index.html

Para ver los productos cargados se utiliza el endpoint
  /api/productos/vista

Nota: 
Para ejecutar cada branche se debe instalar el modulo correspondiente al motor de plantillas indicado. 
